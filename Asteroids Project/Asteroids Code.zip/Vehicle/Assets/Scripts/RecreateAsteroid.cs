﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecreateAsteroid : MonoBehaviour {

    public List<GameObject> asteroids;
    public GameObject asteroid;
    public float asteroidMin;

	// Use this for initialization
	void Start ()
    {
        if(asteroidMin == 0)
        {
            asteroidMin = 3;
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
        asteroids = this.GetComponent<CollisionDetection>().objects;

        //If traveling out of bounds, wrap Asteroid
        for (int i = 0; i < asteroids.Count; i++)
        {
            if (asteroids[i].transform.position.x >= 10)
            {
                asteroids[i].transform.position = new Vector3(-10, asteroids[i].transform.position.y, 0);

            }
            else if (asteroids[i].transform.position.x <= -10)
            {
                asteroids[i].transform.position = new Vector3(10, asteroids[i].transform.position.y, 0);
            }

            //Y
            else if (asteroids[i].transform.position.y >= 6)
            {
                asteroids[i].transform.position = new Vector3(asteroids[i].transform.position.x, -5, 0);
            }
            else if (asteroids[i].transform.position.y <= -6)
            {
                asteroids[i].transform.position = new Vector3(asteroids[i].transform.position.x, 5, 0);
            }
        }


        //Maintain at least n asteroids in play at all times
        if (asteroids.Count < asteroidMin)
        {
            Instantiate(asteroid, new Vector3(-10, -5, 0), Quaternion.identity);
        }
        
    }

    /*public void CreateNewAsteroid(GameObject newAsteroid, int indexOf)
    {
        Instantiate(newAsteroid, new Vector3(Random.Range(-9,9), Random.Range(6,7), 0), Quaternion.identity);
        asteroids.Add(newAsteroid);
        asteroids.RemoveAt(indexOf);
        this.GetComponent<CollisionDetection>().objects.RemoveAt(indexOf);
        this.GetComponent<CollisionDetection>().objects.Insert(indexOf, newAsteroid);
    }
    */
}
