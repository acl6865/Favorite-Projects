﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidMovement : MonoBehaviour {
    
    //Movement
    public float speedDivMin;
    public float speedDivMax;
    float randXdir;
    float randYdir;
    float xSpeed;
    float ySpeed;
    public Vector3 velocity;

    //Size Creation
    public float scaleMin;
    public float scaleMax;
    float scale;

    //When active, this boolean (set at creation or in Collision Detection) initiates destruction. Should probably be a method
    public bool destroyed;

    //Child Creation
    public GameObject asteroid;
    GameObject newAsteroid1;
    GameObject newAsteroid2;
    public bool child;
    public int finalScore;

    //Sprite References
    int randomSpriteNo;
    public List<Sprite> spriteList;


    // Use this for initialization
    void Start ()
    {
        //Start the objects moving in a random direction
        randXdir = Random.Range(-1.0f, 1.0f);
        xSpeed = Random.Range(speedDivMin,speedDivMax);
        randYdir = Random.Range(-1.0f, 1.0f);
        ySpeed = Random.Range(50, 300);
        velocity = new Vector3((randXdir/xSpeed), (randYdir/ySpeed), 0);
        destroyed = false;

        //Grant Random scale for parents only
        if(child == false)
        {
            scale = Random.Range(scaleMin, scaleMax);
            transform.localScale = new Vector3(scale, scale, 1);
            randomSpriteNo = Random.Range(0, spriteList.Count);
            gameObject.GetComponent<SpriteRenderer>().sprite = spriteList[randomSpriteNo];
        }


        //Always add the Astroid to Collision Detection
        GameObject.Find("SceneManager").GetComponent<CollisionDetection>().objects.Add(this.gameObject);

    }
	
	// Update is called once per frame
	void Update ()
    {
        //Update the position
        transform.position += velocity;

        //If colliding with a bullet
        if(destroyed == true)
        {
            //Create two Smaller asteroids if this asteroid is large
            if(transform.localScale.magnitude >= 3)
            {
                //Children will always have the parent's sprite and 1/2 the parent's size.
                newAsteroid1 = Instantiate(asteroid, transform.position, Quaternion.identity);
                newAsteroid1.transform.localScale = (transform.localScale / 2);
                newAsteroid1.GetComponent<AsteroidMovement>().child = true;
                newAsteroid1.GetComponent<SpriteRenderer>().sprite = gameObject.GetComponent<SpriteRenderer>().sprite;

                newAsteroid2 = Instantiate(asteroid, transform.position, Quaternion.identity);
                newAsteroid2.transform.localScale = (transform.localScale / 2);
                newAsteroid2.GetComponent<AsteroidMovement>().child = true;
                newAsteroid2.GetComponent<SpriteRenderer>().sprite = gameObject.GetComponent<SpriteRenderer>().sprite;
            }

            //Add Score based inversely on asteroid's size (Only while score is being counted
            if (GameObject.Find("SceeManager") == null)
            {
                GameObject.Find("SceneManager").GetComponent<Score>().score += ((10 - (int)gameObject.transform.localScale.x) * 10);


                //Destroy this asteroid
                GameObject.Find("SceneManager").GetComponent<CollisionDetection>().objects.Remove(this.gameObject);
                GameObject.Find("SceneManager").GetComponent<RecreateAsteroid>().asteroids.Remove(this.gameObject);
            }
            Destroy(gameObject);
        }
        
    }
}
